const express = require('express');
const mongoose = require('mongoose');
const bodyParser = require('body-parser');
const passport = require('passport');
const session = require('express-session');
const flash = require('connect-flash');
const path = require('path');
require('dotenv').config(); // To use environment variables from a .env file
const db = require('./config/keys.js').mongoURI;

// Import Routes
const indexRoutes = require('./routes/index');
const itemRoutes = require('./routes/items');
const authRoutes = require('./routes/auth');

// Passport Config
 // Include passport configuration

// App Initialization
const app = express();

// Connect to MongoDB

// Get the database URI from the environment variables
const dbURI = 'mongodb+srv://finalproject:<Harshpatel%401508>@database1.yjk8v.mongodb.net/finalproject?retryWrites=true&w=majority&appName=Database1';

// Connect to the database
mongoose.connect(dbURI)
.then(() => {
  console.log('Connected to MongoDB successfully');
})
.catch((error) => {
  console.error('Error connecting to MongoDB:', error.message);
});



// Set View Engine
app.set('view engine', 'hbs');
app.set('views', path.join(__dirname, 'views'));

// Middleware
app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());
app.use(express.static(path.join(__dirname, 'public')));

// Express Session
app.use(
  session({
    secret: process.env.SESSION_SECRET || 'defaultsecret',
    resave: false,
    saveUninitialized: true,
  })
);

// Passport Middleware
app.use(passport.initialize());
app.use(passport.session());

// Flash Middleware
app.use(flash());

// Global Variables Middleware
app.use((req, res, next) => {
  res.locals.success_msg = req.flash('success_msg');
  res.locals.error_msg = req.flash('error_msg');
  res.locals.error = req.flash('error');
  res.locals.user = req.user || null; // To access the logged-in user in views
  next();
});

// Routes
app.use('/', indexRoutes);
app.use('/items', itemRoutes);
app.use('/auth', authRoutes); // Authentication routes

// 404 Handler
app.use((req, res) => {
  res.status(404).render('404', { title: '404 Not Found' });
});

// Graceful Shutdown
process.on('SIGINT', async () => {
  await mongoose.connection.close();
  console.log('Mongoose disconnected on app termination');
  process.exit(0);
});

// Start the Server
const PORT = process.env.PORT || 3002;
app.listen(PORT, () => console.log(`Server running on http://localhost:${PORT}`));

