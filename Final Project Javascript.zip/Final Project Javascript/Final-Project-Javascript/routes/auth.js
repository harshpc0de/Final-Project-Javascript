const express = require('express');
const router = express.Router();
const passport = require('passport');
const bcrypt = require('bcryptjs');
const User = require('../models/User');

// Register Page
router.get('/register', (req, res) => {
  res.render('register', { title: 'Register' });
});

// Register Handle
router.post('/register', async (req, res) => {
  const { username, password, password2 } = req.body;
  const errors = [];

  if (password !== password2) {
    errors.push({ msg: 'Passwords do not match' });
  }

  if (errors.length > 0) {
    return res.render('register', { errors, username, password, password2 });
  }

  try {
    let user = await User.findOne({ username });
    if (user) {
      errors.push({ msg: 'Username already exists' });
      return res.render('register', { errors, username, password, password2 });
    }

    const hash = await bcrypt.hash(password, 10);
    user = new User({ username, password: hash });
    await user.save();
    req.flash('success_msg', 'You are registered and can log in');
    res.redirect('/auth/login');
  } catch (err) {
    console.error(err);
    res.status(500).send('Server Error');
  }
});

// Login Page
router.get('/login', (req, res) => {
  res.render('login', { title: 'Login' });
});

// Login Handle
router.post('/login', (req, res, next) => {
  passport.authenticate('local', {
    successRedirect: '/items',
    failureRedirect: '/auth/login',
    failureFlash: true,
  })(req, res, next);
});

// Logout Handle
router.get('/logout', (req, res) => {
  req.logout(() => {
    req.flash('success_msg', 'You are logged out');
    res.redirect('/auth/login');
  });
});

module.exports = router;