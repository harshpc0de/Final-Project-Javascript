module.exports = {
    mongoURI: 'mongodb+srv://finalproject:<Harshpatel%401508>@database1.yjk8v.mongodb.net/finalproject?retryWrites=true&w=majority&appName=Database1',
  };